<!--THIS IS A PARTIAL THAT CONTAINS ALL FOOTER INFORMATION OF PAGE-->
</div>  
                <!--SIDEBAR-->
                <div class="our-story">
                    <div class="hook">
                        <span>From little league to the big leagues. <br/>We ALL wanted to play. Now we ALL can. <br/>Welcome to America's Past Time.</span>
                    </div>
                    <div class="full-story">
                        <a href="http://www.google.com">View Our Story</a>
                    </div>
                </div> 
            </div>
            <!--FOOTER-->
            <footer class="footer-main flex-container">
                <div class="social flex-item-footer">
                    <h1 class="h3">Connect With Us!</h1>
                        <p class="footer-section">Like us on our social networks and keep up with everything "fantasy baseball"
                    </p>
                    <a href="http://facebook.com/MLBFantasyTime" class="link facebook fa" target="_parent"><span class="fa fa-facebook-square"></span></a>
                    
                    <a href="http://twiter.com/MLBFantasyTime" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a>
                    
                    <a href="http://plus.google.com/MLBFantasyTime" class="link google-plus" target="_parent"><span class="fa fa-google-plus-square"></span></a>
                    
                    <a href="http://instagram.com/MLBFantasyTime" class="link instagram google-plus" target="_parent"><span class="fa fa-instagram"></span></a>
                </div>
                <div class="section2 footer-section flex-item-footer">
                    <h1 class="h3">Join Our Monthly Newsletter!</h1>
                        <p>Sign up for our free monthly snapshot of Fantasy Baseball. Our top picks delivered right to your inbox. After all, everyone needs a little baseball intel to draft and make those winning trades! League commissioners welcome.
                        </p>
                </div>
                <div class="section3 footer-section flex-item-footer">
                    <h1 class="h3">Be Featured On Our Site!</h1>
                        <p>Are you sharing the joy of America's Past Time with your family or friends? From baseball opening day tail gates to the World Series, share with us your favorite game day pictures for a chance to be featured on our site!
                        </p>
                </div>
            </footer> 
            <div class="terms">
                <p><a>Terms & Conditions</a><span> <a>| Privacy</span></a><span><a> | Fantasy Baseball Clinic © 2017</a></span></span></p>
            </div> 
        </div>  

        <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.12.0.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
    </body>

    <footer>

    </footer>
</html>
