<?php get_header(); 
/* THIS IS THE TEMPLATE FOR HOME PAGE/FRONT PAGE OF THE WEBSITE */
?>

<div class="home-hero" id="bg">
    <div class="sidestep-wrapper">
        <div class="sidestep-headline1">MAKING THE FANTASY SPORT</div>
            <div class="sidestep-headline2">MORE REAL THAN EVER</div>
    </div>
</div>

<div class="flex-container width">

    <div class="flex-container width">
            <div class="flex-items">

                <?php while(have_posts()) : the_post(); ?>
                <h2 class="promo-image" href="<?php the_permalink(); ?>"> <?php the_title();?></h2>
                <?php the_post_thumbnail('full'); ?>
                <?php endwhile; ?>
            </div>

</div>
<?php get_footer(); ?>