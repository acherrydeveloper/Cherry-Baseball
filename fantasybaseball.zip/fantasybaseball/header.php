
<!--THIS IS A PARTIAL THAT CONTAINS ALL HEADER INFORMATION OF PAGE-->
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php bloginfo('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
        <link href="https://fonts.googleapis.com/css?family=Hammersmith+One|Permanent+Marker" rel="stylesheet">
        <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" media="screen"/>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
        <?php wp_head();?>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
        
        <!-- Skeleton of Site Starts here - Mobile First Approach-->
        
        <div id="wrapper">
            <!--HEADER-->
            <div class= "promo-top"></div>
                <a class="promo" href="www.google.com">
                    <div class="container">
                        <div class="title">Win a Signed Baseball!</div>
                        <div class="content">
                            <span class="short">Enter Now!</span>
                        </div>
                    </div>
                </a> 

            <header id="header" class="header">
                <div class="menu-outer">
                    <nav class="table">
                        <img class="web-logo" src="wp-content/uploads/2017/03/fantasy_baseball_clinic.png" />
                    <?php wp_nav_menu(); ?>
                        <!--<ol class="nav-primary">
                            
                            <li class="level0">
                                <a href="http://www.google.com" class="level0">
                                HOME</a>
                            </li>
                            <li class="level0">
                                 <a href="http://www.google.com" class="level0">NEWS
                                </a>
                            </li>
                            <li class="level0">
                                 <a href="http://www.google.com" class="level0">DRAFT
                                </a>
                            </li>
                            <li class="level0">
                                 <a href="http://www.google.com" class="level0">ROAD TRIP
                                </a>
                            </li>
                        </ol>-->
                    </nav>
                </div>
            </header>
            <!--INDEX/CONTENT-->
            <div id="matter" class="matter">