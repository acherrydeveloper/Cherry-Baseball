<?php
/*THIS IS THE TEMPLATE FILE FOR INDIVIDUAL BLOG POSTS*/
?>

<?php get_header(); 
/* THIS IS THE DEFAULT TEMPLATE FOR BLOG PAGE WHERE ALL BLOG POSTS ARE */
?>
    <?php while(have_posts()) : the_post(); ?>

        <div class="flex-container width">
            <div class="flex-items">
                <a class="promo-image" href="<?php the_permalink(); ?>">
                <h2><?php the_title(); ?></h2>
                <p><?php the_time('F jS Y');?> </p>
                <?php the_post_thumbnail('full'); ?>
                </a>
                <p><?php the_content();?></p>
            </div>

    <?php endwhile; ?>

<?php get_footer(); ?>